#ifndef __SO_FSO_2324_IPC_BWDELAY__
#define __SO_FSO_2324_IPC_BWDELAY__

#include <stdint.h>

void bwDelay(uint32_t n);

#endif // __SO_FSO_2324_IPC_BWDELAY__

