# Some questions concerning Human-Centered design of interactive systems and methods

## Q

1. What is the subject of the ISO standard 13407 (1999)?
2. There are several proposals of Human-Centered methodologies; (also referred to as UCD-User Centered Design) what are their main characteristics?
3. Give examples of different Human-Centered methodologies.
4. What are the benefits of using a Human-Centered Design approach in developing interactive systems?
5. Personas are a method that can be used in the design of interactive systems; explain what are personas and their benefits.
6. How should personas be developed?
7. There are several types of personas; explain the main difference between fictional personas and the other types of personas.
8. Describe a minimal set of characteristics that can be used to define a persona
9. What is a scenario? And why are they useful in the design of interactive systems?
10. Scenarios may also be used in usability evaluation; give an example.
11. How are personas related to scenarios?
12. What should be considered when writing a scenario?
13. What is the difference among scenarios, user stories and use cases?
14. What do scenarios, user stories and use cases have in common?
15. After defining scenarios, it is necessary to analyze the main tasks to be performed in the context of the scenario. This analysis can be done informally by asking questions; indicate a minimum set of questions.
16. Task analysis is a very useful and may be done using Hierarchical task Analysis (HTA); what are its main characteristics?
17. What for may task analysis be used?
18. Think of some everyday task and perform HTA using its graphical form.
19. What type of plans my an HTA include?
20. What are the main information sources for a task analysis?
21. Are task analysis methods objective? Why?
22. When to stop decomposition is an important issue in applying HTA. State a rule that can be used to make that decision.
23. What is the Wizard of Oz method? Give an example of a situation in which it can be useful.
24. What are the main characteristics of participatory design?
25. What techniques may be used in the scope of participatory design to get information from the users?
26. What is modeled by the cognitive model GOMS?
27. What are goals, operators, methods and selections in GOMS?
28. What are the limitations of GOMS?
29. What is the closure problem that may be detected using GOMS? Think of an example (beyond the ones in the slides)
30. What kind of information is it possible to obtain by analyzing a GOMS decomposition?
31. What is the Fitts law?
32. What are the main differences between a GOMS decomposition and a HTA?

## R

1. **ISO Standard 13407 (1999)**:
   - The subject is Human-Centered Design processes for interactive systems, providing guidelines for designing user-friendly interfaces.

2. **Characteristics of Human-Centered Design (UCD) Methodologies**:
   - Focus on users and their needs throughout the design process.
   - Iterative design involving user feedback.
   - Multidisciplinary approach integrating perspectives from various fields.
   - Emphasis on usability and user experience.

3. **Examples of Human-Centered Methodologies**:
   - Contextual Design.
   - Participatory Design.
   - Scenario-Based Design.
   - User-Centered Design (UCD).

4. **Benefits of Human-Centered Design**:
   - Improved usability and user satisfaction.
   - Reduced development costs and time by identifying issues early.
   - Higher user engagement and adoption rates.
   - Enhanced product quality and performance.

5. **Personas**:
   - Fictional characters representing user types based on real user data.
   - Benefits include better understanding of user needs, improved communication among team members, and more targeted design decisions.

6. **Developing Personas**:
   - Conduct user research (interviews, surveys, observations).
   - Identify patterns and group users with similar behaviors and goals.
   - Create detailed profiles with demographics, goals, frustrations, and behaviors.

7. **Types of Personas**:
   - **Fictional Personas**: Based on assumptions and hypothetical data.
   - **Other Types (e.g., Data-Driven Personas)**: Based on real user data and insights.

8. **Minimal Set of Characteristics for a Persona**:
   - Name and photo.
   - Demographics (age, gender, occupation).
   - Goals and motivations.
   - Frustrations and pain points.
   - Behavioral patterns.

9. **Scenario**:
   - A narrative describing a specific instance of user interaction with the system.
   - Useful for envisioning how users will interact with the system, identifying potential issues, and validating design choices.

10. **Scenarios in Usability Evaluation**:
    - Example: Testing an online shopping site by having users complete a purchase using a provided scenario.

11. **Personas and Scenarios**:
    - Personas represent user archetypes, while scenarios illustrate how these personas interact with the system.

12. **Writing a Scenario**:
    - Include context, user goals, tasks, and environment.
    - Be specific and detailed to capture the user experience.

13. **Difference Among Scenarios, User Stories, and Use Cases**:
    - **Scenarios**: Detailed narratives focusing on user interaction.
    - **User Stories**: Short, simple descriptions of a feature from the user's perspective.
    - **Use Cases**: Detailed, structured descriptions of system interactions, including preconditions, steps, and outcomes.

14. **Commonalities of Scenarios, User Stories, and Use Cases**:
    - Focus on user needs and system functionality.
    - Help in understanding requirements and designing user-friendly systems.

15. **Questions for Task Analysis**:
    - What tasks are users trying to accomplish?
    - What are the steps involved in each task?
    - What are the possible variations and exceptions?
    - What tools and information do users need?

16. **Hierarchical Task Analysis (HTA)**:
    - Breaks down tasks into subtasks and operations.
    - Organized hierarchically to show relationships.
    - Focuses on the goals and plans of users.

17. **Uses of Task Analysis**:
    - Identifying user requirements.
    - Informing interface design.
    - Evaluating and improving system usability.

18. **HTA Example**:
    - Task: Making a cup of tea.
      - 1. Boil water.
        - 1.1 Fill kettle.
        - 1.2 Turn on kettle.
      - 2. Prepare teacup.
        - 2.1 Place teabag in cup.
      - 3. Pour water into cup.
      - 4. Let tea steep.
      - 5. Remove teabag and add milk/sugar.

19. **Types of Plans in HTA**:
    - Fixed sequence.
    - Optional steps.
    - Contingent plans based on conditions.

20. **Information Sources for Task Analysis**:
    - User observations.
    - Interviews and surveys.
    - Existing documentation and training materials.

21. **Objectivity of Task Analysis Methods**:
    - Partially objective; relies on accurate data collection but includes subjective interpretation.

22. **Rule for Stopping Decomposition in HTA**:
    - Stop when further decomposition does not add significant value or clarity to understanding the task.

23. **Wizard of Oz Method**:
    - A research method where a human simulates the system's responses.
    - Example: Testing a voice-controlled assistant by having a human provide the responses.

24. **Participatory Design Characteristics**:
    - Involves users actively in the design process.
    - Collaborative and iterative.
    - Emphasizes mutual learning and co-creation.

25. **Participatory Design Techniques**:
    - Workshops and focus groups.
    - Brainstorming sessions.
    - Prototyping and user testing.

26. **GOMS Cognitive Model**:
    - Models user interactions to predict task performance.
    - Focuses on Goals, Operators, Methods, and Selection rules.

27. **GOMS Components**:
    - **Goals**: Objectives the user wants to achieve.
    - **Operators**: Basic actions performed to achieve goals.
    - **Methods**: Procedures or sequences of operators.
    - **Selections**: Rules for choosing among methods.

28. **Limitations of GOMS**:
    - Assumes rational and error-free behavior.
    - Not suitable for tasks requiring creativity or social interaction.

29. **Closure Problem in GOMS**:
    - Issue where users are unsure if a subgoal is complete.
    - Example: Unclear feedback after submitting a form online.

30. **Information from GOMS Decomposition**:
    - Task complexity.
    - Time estimates for task completion.
    - Potential bottlenecks and areas for improvement.

31. **Fitts' Law**:
    - Predicts the time required to move to and select a target.
    - The time is a function of the distance to the target and the target size.

32. **Differences Between GOMS and HTA**:
    - **GOMS**: Focuses on cognitive processes and predicting task performance.
    - **HTA**: Focuses on task decomposition and understanding task structure.
