# Some questions concerning Interaction styles

## Q

1. Why is it common to combine several interaction styles in the same user interface?
2. Give an example of a common situation of combining two different interaction styles to better support users’ tasks.
3. What are the main potential advantages of menus? What is needed for these advantages to manifest in a user interface?
4. What type of tasks do menus support well?
5. Card sorting is an interesting method to use in menu design; describe how to use it in this context and what kind of information may provide.
6. What are the characteristics defining direct manipulation?
7. What are semantic and articulatory distances in direct manipulation user interfaces?
8. Give examples illustrating user interfaces with different articulatory distance to delete a file from a folder.
9. What are the disadvantages of direct manipulation as interaction style?
10. What are the advantages and disadvantages of function keys as an interaction style?
11. State three guidelines to function key usage in an interactive system.
12. Compare the advantages of menu and fill-in-form user interfaces.
13. What are the main disadvantages of fill-in-form based user interfaces?
14. What are the basic usability goals for a command language user interface?
15. What techniques can be used to improve the usability of a command language?
16. What are the advantages and disadvantages of command languages concerning usability?
17. To what type of users are command languages more adequate?
18. Give examples of CUIs (Conversational user interfaces).
19. What kind of input/output devices can be used in CUIs?
20. Consider the Shneiderman’s Eight Golden Rules of Dialog Design and compare them with the Nielson’s Usability Heuristics.

## R

1. **Combining Interaction Styles**:
   - Enhances flexibility and usability.
   - Supports diverse user tasks and preferences.
   - Balances ease of use for novices with efficiency for experienced users.

2. **Example of Combining Interaction Styles**:
   - Combining **menus** with **direct manipulation**: A file management system where users can select files from a menu and drag-and-drop them into folders.

3. **Advantages of Menus**:
   - Self-explanatory and easy to learn.
   - Reduces memory load by presenting options.
   - Prevents errors by limiting choices.
   - **Needs**: Consistent structure, logical grouping of items, clear labels, and responsive design.

4. **Tasks Supported by Menus**:
   - Navigation through applications.
   - Configuration and settings adjustments.
   - Accessing commands and functions.

5. **Using Card Sorting in Menu Design**:
   - **Process**: Users group cards labeled with menu items into categories.
   - **Information**: Reveals user expectations for grouping and labeling, identifies logical menu structures, and improves the organization of menu items.

6. **Characteristics of Direct Manipulation**:
   - Continuous representation of objects.
   - Physical actions instead of complex syntax.
   - Immediate feedback and reversible actions.

7. **Semantic and Articulatory Distances**:
   - **Semantic Distance**: The gap between user goals and the system’s actions.
   - **Articulatory Distance**: The difference between the physical form of actions and their meanings.

8. **Examples of Different Articulatory Distances**:
   - **Low Articulatory Distance**: Dragging a file to a trash bin icon to delete it.
   - **High Articulatory Distance**: Typing a command like `rm filename` in a command-line interface.

9. **Disadvantages of Direct Manipulation**:
   - May not be suitable for complex or abstract tasks.
   - Can be inefficient for repetitive actions.
   - Requires good visual representation and can be screen-space intensive.

10. **Advantages and Disadvantages of Function Keys**:
    - **Advantages**: Fast access to functions, reduces repetitive actions, can be used without visual attention.
    - **Disadvantages**: Limited number of keys, difficult to remember functions, not self-explanatory.

11. **Guidelines for Function Key Usage**:
    - Use consistent and logical key mappings.
    - Provide clear labels or tooltips.
    - Allow customization and shortcuts for frequent users.

12. **Advantages of Menus and Fill-in-Forms**:
    - **Menus**: Easy to navigate, prevent errors, reduce memory load.
    - **Fill-in-Forms**: Guide users through data entry, good for structured tasks, allow detailed inputs.

13. **Disadvantages of Fill-in-Forms**:
    - Can be time-consuming to complete.
    - May overwhelm users with many fields.
    - Error-prone if validation is not robust.

14. **Usability Goals for Command Language UIs**:
    - Precision and efficiency.
    - Ease of learning and remembering commands.
    - Minimizing errors.

15. **Techniques to Improve Command Language Usability**:
    - Provide autocomplete and suggestions.
    - Offer comprehensive help and documentation.
    - Use consistent and logical syntax.

16. **Advantages and Disadvantages of Command Languages**:
    - **Advantages**: Powerful and flexible, efficient for experienced users, minimal screen space.
    - **Disadvantages**: Steep learning curve, error-prone, not intuitive.

17. **Type of Users for Command Languages**:
    - Experienced users with technical proficiency.
    - Users needing precise and complex control over the system.

18. **Examples of CUIs**:
    - Chatbots (e.g., customer service bots).
    - Voice assistants (e.g., Amazon Alexa, Google Assistant).

19. **Input/Output Devices for CUIs**:
    - **Input**: Microphones, keyboards, touchscreens.
    - **Output**: Speakers, text displays, screens.

20. **Comparison of Shneiderman’s Eight Golden Rules and Nielsen’s Usability Heuristics**:
    - Both focus on creating intuitive, efficient, and user-friendly interfaces.
    - **Shneiderman’s Rules**:
      1. Strive for consistency.
      2. Enable frequent users to use shortcuts.
      3. Offer informative feedback.
      4. Design dialogs to yield closure.
      5. Offer error prevention and simple error handling.
      6. Permit easy reversal of actions.
      7. Support internal locus of control.
      8. Reduce short-term memory load.
    - **Nielsen’s Heuristics**:
      1. Visibility of system status.
      2. Match between system and the real world.
      3. User control and freedom.
      4. Consistency and standards.
      5. Error prevention.
      6. Recognition rather than recall.
      7. Flexibility and efficiency of use.
      8. Aesthetic and minimalist design.
      9. Help users recognize, diagnose, and recover from errors.
      10. Help and documentation.
    - **Differences**: Shneiderman’s rules focus more on user interaction flow, while Nielsen’s heuristics cover broader aspects of usability and system feedback.
