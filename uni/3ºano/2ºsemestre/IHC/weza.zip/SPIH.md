# SPIH
## Q
1. - Porque é fundamental conhecer bem o perfil dos utilizadores alvo dum sistema interactivo quando se inicia o processo de desenvolvimento?
2. - Que aspetos do perfil dos utilizadores são mais relevantes para o design dum sistema interativo? 
3. - O SPIH é um aspeto do perfil dos utilizadores relevante para o design dum sistema interativo e inclui diferentes tipos de memória; diga as que conhece e defina-as resumidamente
4. - Uma destas memórias é considerada a maior limitação do SPIH; qual é e porquê? 
5. - A memória de longa duração é considerada um ponto forte do SPIH; porquê?
6. - Qual a capacidade e duração aproximada da memória de curta duração (ou de trabalho)? 
7. - Em que consiste o fenómeno de chunking? Porque é que deve ser considerado no design de interfaces de utilizador? Dê um exemplo. 
8. - Quais as principais características relevantes para o design de sistemas interativos do processo conhecido como reconhecimento de padrões? 
9. - Que outros sentidos humanos, para além da visão e audição, podem ser relevantes em sistemas de realidade virtual? Porquê?
10. - Porque é que a memória de curta duração ou de trabalho é uma limitação que deve ser tida em conta no design de interfaces de utilizador? Dê um exemplo de situação em que não esteja a ser considerada esta limitação e indique como corrigir por forma a considerar essa limitação.
11. - Dê um exemplo ilustrativo de como explorar o processo de atenção seletiva involuntário para melhorar a usabilidade de uma interface de utilizador. 
12. - Que tipo de ajuda (sintática ou semântica) necessitam mais utilizadores com muita experiência da tarefa, mas pouca do sistema que têm que usar? (Por exemplo um funcionário bancário com muita experiência na sua profissão, que começa a usar um sistema novo)
13. - Uma das heurísticas de usabilidade de Jakob Nielson é “Recognition rather than recall”. Explique o que significa e dê um exemplo ilustrativo de como se pode usar na escolha de estilos de interação a usar numa interface de utilizador.
14. - Que características físicas dos utilizadores devem ser consideradas no desenvolvimento de sistemas interativos? Dê exemplos do impacto que podem ter na UX do sistema.
15. - Como é que uma interface de utilizador pode promover bons modelos mentais dos utilizadores? 

## R
1. **Fundamental Conhecer o Perfil dos Utilizadores**:
   - Facilita a criação de interfaces intuitivas.
   - Alinha-se com as expectativas e necessidades dos utilizadores.
   - Melhora a usabilidade e experiência do utilizador.
   - Reduz erros e frustrações.

2. **Aspetos Relevantes do Perfil dos Utilizadores**:
   - Experiência prévia com sistemas similares.
   - Nível de literacia tecnológica.
   - Necessidades e preferências específicas.
   - Contexto de uso (e.g., ambiente, dispositivos).

3. **Tipos de Memória no SPIH**:
   - **Memória Sensorial**: Regista informações sensoriais por milissegundos.
   - **Memória de Curta Duração**: Armazena informações temporariamente para uso imediato.
   - **Memória de Longa Duração**: Armazena informações por períodos prolongados.

4. **Maior Limitação do SPIH**:
   - **Memória de Curta Duração**: Limitada a cerca de 7±2 itens, dificultando o processamento de grandes quantidades de informações simultâneas.

5. **Força da Memória de Longa Duração**:
   - Capacidade praticamente ilimitada.
   - Armazena informações por longos períodos, facilitando a aprendizagem e a recuperação de conhecimento.

6. **Capacidade e Duração da Memória de Curta Duração**:
   - Capacidade: 7±2 itens.
   - Duração: Aproximadamente 20-30 segundos sem reforço.

7. **Fenómeno de Chunking**:
   - Agrupamento de informações em blocos significativos.
   - Exemplo: Dividir um número de telefone em grupos (123-456-7890) para facilitar a memorização.

8. **Reconhecimento de Padrões**:
   - Identificação rápida de padrões familiares.
   - Utilização de experiências passadas para interpretar informações.

9. **Sentidos Relevantes em VR Além da Visão e Audição**:
   - **Tato**: Feedback háptico melhora a imersão.
   - **Olfato**: Adiciona realismo às experiências.

10. **Limitação da Memória de Curta Duração**:
    - Exemplo: Longas listas de comandos sem agrupamento.
    - Correção: Usar menus hierárquicos e chunking para organizar informações.

11. **Atenção Seletiva Involuntária**:
    - Uso de cores vibrantes para destacar notificações importantes.
    - Exemplo: Botão de alerta vermelho em um painel de controle.

12. **Tipo de Ajuda Necessária**:
    - **Sintática**: Explicações sobre como operar o sistema.
    - Exemplo: Tutoriais passo a passo para novos usuários de software bancário.

13. **Recognition Rather Than Recall**:
    - Preferir reconhecimento de opções visíveis a recordar comandos.
    - Exemplo: Uso de ícones e menus dropdown em vez de comandos de linha de texto.

14. **Características Físicas dos Utilizadores**:
    - **Altura**: Ajuste de altura de monitores.
    - **Força**: Resistência de teclas em teclados ergonômicos.

15. **Promover Bons Modelos Mentais**:
    - Usar metáforas familiares e consistentes.
    - Dar feedback claro e imediato sobre ações do utilizador.