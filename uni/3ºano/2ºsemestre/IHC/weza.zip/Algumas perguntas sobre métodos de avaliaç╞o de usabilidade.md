# Algumas perguntas sobre métodos de avaliação de usabilidade

## Q

1. - Porque é que a avaliação de Experiência de Utilizador (UX) e usabilidade fundamental no processo de desenvolvimento de qualquer sistema interactivo?
2. - A avaliação Heurística é um método de avaliação analítico ou empírico? Porquê?
3. - Qual o resultado de uma avaliação heurística a ser fornecido à equipe de projecto?
4. - A avaliação heurística é um método de avaliação objectivo ou subjectivo? Porquê?
5. - É possível usar diferentes listas de heurísticas? Porquê?
6. - Que vantagem vê em classificar um potencial problema de usabilidade através da heurística (ou heurísticas) que não é cumprida?
7. - Qual o interesse em fornecer um grau de gravidade para cada problema?
8. - O que se deve ter em conta para atribuir a gravidade de um problema?
9. - Porque devem os analistas trabalhar independentemente numa primeira fase?
10. - Como se pode escolher o n. de avaliadores que devem fazer a avaliação heurística?
11. - Em que alturas do desenvolvimento de UIs pode/deve ser utilizada?
12. - Pode referir uma limitação importante da avaliação heurística?
13. - Como se pode minorar o facto da avaliação heurística ser subjectiva?
14. - A avaliação heurística não deve ser usada como único método de avaliação de usabilidade. Porquê?
15. - Pode referir um método de avaliação de usabilidade empírico?
16. - O Cognitive Walkthrough(CW) é um método analítico? Porquê?
17. - Qual o principal objetivo do Cognitive Walkthrough?
18. - Pode indicar duas regras a aplicar num teste de usabilidade em relação a ética?
19. - Que métodos de avaliação de usabilidade são usados num teste de usabilidade?
20. - Os métodos de inquérito podem ser questionários e entrevistas; diga quais as vantagens e desvantagens de cada um.
21. - O que são as variáveis dependentes numa experiência controlada?
22. - O que são as variáveis independentes numa experiência controlada?
23. - O think-aloud é uma variante do método de observação; porque tem este nome?
24. - Pode indicar uma desvantagem do método de observação think-aloud?
25. - E uma vantagem?
26. - Que vantagens tem a utilização de protótipos de baixa fidelidade (de papel) na avaliação de usabilidade?
27. - O que é o protocolo de uma experiência controlada?
28. - Qual a diferença entre o design experimental entre-grupos e dentro-de-grupos numa experiência controlada?
29. - O que é a hipótese numa experiência controlada?
30. - O que são os métodos de avaliação de usabilidade baseados em modelos?
31. - Que modelos conhece que podem ser utilizados na avaliação de usabilidade baseada em modelos?
32. - Qual a diferença entre avaliações de campo e de laboratório?
33. - Que desvantagens têm as avaliações de campo relativamente às de laboratório?
34. - E vantagens?
35. - Qual a diferença entre métodos de avaliação de usabilidade empíricos e analíticos?
36. - O Streamlined Cognitive Walkthrough é uma versão simplificada do método originalmente proposto. Quais as perguntas que devem ser feitas em cada passo?
37. - Descreva como se realiza uma avaliação heurística.
38. - Em que fase do processo de desenvolvimento dum Sistema interactivo deve ser usado o Cognitive Walkthrough. Porquê?
39. - Descreva como se realiza um Streamlined Cognitive Walkthrough.
40. - A observação é um método de avaliação de usabilidade muito usado, nomeadamente nos testes de usabilidade e pode ser directa ou indirecta. Diga quais as vantagens e desvantagens de cada uma destas variantes de observação.

## R

1. **Fundamentalidade da Avaliação de UX e Usabilidade**:
   - **Identificação de Problemas**: Detecta problemas que podem ser resolvidos antes do lançamento.
   - **Melhoria de Satisfação**: Aumenta a satisfação e a experiência do usuário.
   - **Eficiência e Eficácia**: Melhora a eficiência e eficácia do sistema.

2. **Avaliação Heurística: Analítico ou Empírico**:
   - **Analítico**: Baseia-se na análise de especialistas usando heurísticas predefinidas, não em testes com usuários reais.

3. **Resultado da Avaliação Heurística**:
   - **Relatório de Problemas**: Lista de problemas de usabilidade identificados, categorizados por heurísticas violadas, com recomendações de melhorias.

4. **Objetividade ou Subjetividade da Avaliação Heurística**:
   - **Subjetivo**: Depende do julgamento e experiência dos avaliadores, que podem ter diferentes interpretações das heurísticas.

5. **Uso de Diferentes Listas de Heurísticas**:
   - **Flexibilidade**: Heurísticas podem ser adaptadas ao contexto específico do sistema ou à experiência dos avaliadores.

6. **Classificação por Heurísticas Violadas**:
   - **Clareza e Foco**: Facilita a identificação de padrões de problemas e áreas específicas que precisam de melhorias.

7. **Grau de Gravidade dos Problemas**:
   - **Prioritização**: Ajuda a priorizar a correção dos problemas com maior impacto na usabilidade.

8. **Atribuição de Gravidade**:
   - **Critérios**: Frequência, impacto, persistência e facilidade de correção do problema.

9. **Trabalho Independente dos Analistas**:
   - **Redução de Viés**: Garante uma análise mais abrangente e imparcial dos problemas.

10. **Escolha do Número de Avaliadores**:
    - **Equilíbrio**: Idealmente entre 3 a 5 avaliadores para cobrir uma gama ampla de problemas sem redundância excessiva.

11. **Fases para Uso da Avaliação Heurística**:
    - **Durante Todo o Desenvolvimento**: Principalmente nas fases iniciais para identificar problemas precoces e nas revisões finais para refinar o design.

12. **Limitação Importante da Avaliação Heurística**:
    - **Subjetividade**: Dependência do julgamento dos avaliadores pode resultar em inconsistências.

13. **Minimizar a Subjetividade**:
    - **Vários Avaliadores**: Utilizar múltiplos avaliadores e discutir os resultados para obter consenso.

14. **Uso Exclusivo da Avaliação Heurística**:
    - **Complementaridade**: Não capta a experiência real do usuário; deve ser complementada por métodos empíricos como testes com usuários.

15. **Método de Avaliação Empírico**:
    - **Testes de Usabilidade**: Envolvem usuários reais realizando tarefas específicas no sistema.

16. **Cognitive Walkthrough: Analítico?**:
    - **Sim**: Baseia-se na simulação de passos do usuário para avaliar a facilidade de aprendizado e uso.

17. **Objetivo do Cognitive Walkthrough**:
    - **Avaliar a Facilidade de Aprendizado**: Verificar se novos usuários conseguem aprender a usar o sistema de forma eficiente.

18. **Regras Éticas em Testes de Usabilidade**:
    - **Consentimento Informado**: Garantir que os participantes compreendem o estudo.
    - **Privacidade**: Manter a confidencialidade das informações dos participantes.

19. **Métodos Usados em Testes de Usabilidade**:
    - **Observação Direta/Indireta**: Monitorar o comportamento dos usuários.
    - **Think-Aloud**: Pedir aos usuários que verbalizem seus pensamentos enquanto usam o sistema.

20. **Vantagens e Desvantagens de Questionários e Entrevistas**:
    - **Questionários**:
      - *Vantagens*: Coleta rápida, fácil de analisar quantitativamente.
      - *Desvantagens*: Menos profundidade, falta de flexibilidade.
    - **Entrevistas**:
      - *Vantagens*: Informações detalhadas e qualitativas.
      - *Desvantagens*: Demorado, difícil de analisar quantitativamente.

21. **Variáveis Dependentes em Experiência Controlada**:
    - **Resultados Medidos**: O que é observado ou medido, como tempo de tarefa ou taxa de erro.

22. **Variáveis Independentes em Experiência Controlada**:
    - **Manipulações**: Fatores controlados ou alterados pelo pesquisador, como tipo de interface ou condições de uso.

23. **Think-Aloud**:
    - **Nome**: Usuários falam seus pensamentos em voz alta enquanto realizam tarefas, permitindo observação direta do processo cognitivo.

24. **Desvantagem do Think-Aloud**:
    - **Interferência**: Pode alterar o comportamento natural dos usuários.

25. **Vantagem do Think-Aloud**:
    - **Insight Profundo**: Fornece entendimento detalhado dos pensamentos e dificuldades dos usuários.

26. **Vantagens dos Protótipos de Baixa Fidelidade**:
    - **Rápido e Barato**: Facilita iterações rápidas e incorporação de feedback.

27. **Protocolo de Experiência Controlada**:
    - **Plano Detalhado**: Descrição completa dos procedimentos, variáveis, e métodos a serem usados no estudo.

28. **Design Experimental Entre-Grupos vs. Dentro-de-Grupos**:
    - **Entre-Grupos**: Diferentes grupos de participantes testam diferentes condições.
    - **Dentro-de-Grupos**: Os mesmos participantes testam todas as condições.

29. **Hipótese numa Experiência Controlada**:
    - **Suposição Testável**: Declaração clara sobre o que se espera encontrar ou provar no estudo.

30. **Métodos de Avaliação Baseados em Modelos**:
    - **Teóricos**: Baseados em modelos teóricos de interação e usabilidade para prever desempenho.

31. **Modelos Usados na Avaliação Baseada em Modelos**:
    - **GOMS**: Descreve tarefas em termos de metas, operadores, métodos e seleções.
    - **KLM (Keystroke-Level Model)**: Prediz o tempo necessário para realizar tarefas com base em ações básicas.

32. **Avaliações de Campo vs. Laboratório**:
    - **Campo**: Realizadas no ambiente natural do usuário.
    - **Laboratório**: Realizadas em um ambiente controlado.

33. **Desvantagens das Avaliações de Campo**:
    - **Controle Limitado**: Difícil controlar variáveis externas e reproduzir condições.

34. **Vantagens das Avaliações de Campo**:
    - **Realismo**: Resultados mais representativos do uso real.

35. **Diferença entre Métodos Empíricos e Analíticos**:
    - **Empíricos**: Baseados em dados de usuários reais (e.g., testes de usabilidade).
    - **Analíticos**: Baseados na avaliação de especialistas e modelos teóricos (e.g., heurísticas).

36. **Perguntas do Streamlined Cognitive Walkthrough**:
    - O usuário saberá o que fazer?
    - O usuário perceberá que ação tomar?
    - O usuário conseguirá realizar a ação?
    - O usuário perceberá que a ação foi bem-sucedida?

37. **Realização de uma Avaliação Heurística**:
    - **Preparação**: Selecionar heurísticas e avaliadores.
    - **Avaliação Individual**: Avaliadores analisam a interface independentemente.
    - **Discussão em Grupo**: Reunião para consolidar os resultados e discutir problemas identificados.
    - **Relatório Final**: Documentar problemas, heurísticas violadas e recomendações.

38. **Uso do Cognitive Walkthrough no Desenvolvimento**:
    - **Fases Iniciais**: Identificação de problemas de usabilidade desde o início para garantir um design intuitivo e eficiente.

39. **Realização de um Streamlined Cognitive Walkthrough**:
    - **Definir Tarefas**: Escolher tarefas representativas.
    - **Responder Perguntas Chave**: Avaliadores respondem às quatro perguntas principais para cada passo da tarefa.
    - **Documentar Resultados**: Registrar problemas identificados e possíveis soluções.

40. **Observação Direta vs. Indireta**:
    - **Direta**:
      - *Vantagens*: Acesso imediato às ações dos usuários, detalhes ricos.
      - *Desvantagens*: Pode influenciar o comportamento dos usuários, consome mais tempo.
    - **Indireta**:
      - *Vantagens*: Menos intrusiva, pode capturar dados ao longo do tempo.
      - *Desvantagens*: Menos detalhes contextuais, pode perder nuances importantes.
